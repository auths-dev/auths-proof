/* tslint:disable */
/* eslint-disable */

/**
 * JavaScript-facing exact configuration commitment for this distribution.
 *
 * # Errors
 *
 * Returns a JavaScript error only if compiled engine initialization fails.
 */
export function configurationV1(): Uint8Array;

/**
 * JavaScript-facing three-input portable V1 verifier.
 *
 * Protocol failures are canonical result bytes, not JavaScript exceptions.
 * Exceptions are reserved for an internal compiled-registry or result-codec
 * failure.
 *
 * # Errors
 *
 * Returns a JavaScript error only for an internal engine initialization or
 * result encoding failure.
 */
export function verifyV1(proof_cbor: Uint8Array, canonical_action_cbor: Uint8Array, trusted_context_cbor: Uint8Array): Uint8Array;

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
    readonly memory: WebAssembly.Memory;
    readonly configurationV1: () => [number, number, number, number];
    readonly verifyV1: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number, number, number];
    readonly __wbindgen_externrefs: WebAssembly.Table;
    readonly __externref_table_dealloc: (a: number) => void;
    readonly __wbindgen_free: (a: number, b: number, c: number) => void;
    readonly __wbindgen_malloc: (a: number, b: number) => number;
    readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
 * Instantiates the given `module`, which can either be bytes or
 * a precompiled `WebAssembly.Module`.
 *
 * @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
 *
 * @returns {InitOutput}
 */
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
 * If `module_or_path` is {RequestInfo} or {URL}, makes a request and
 * for everything else, calls `WebAssembly.instantiate` directly.
 *
 * @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
 *
 * @returns {Promise<InitOutput>}
 */
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
